package com.example.demo.model;

public enum BookingStatus {
    PENDING,
    ACCEPTED,
    CANCELLED,
    COMPLETED
}
