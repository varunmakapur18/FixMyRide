package com.example.demo.controller;

import com.example.demo.model.Feedback;
import com.example.demo.service.FeedbackService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/feedback")
@CrossOrigin(origins = "http://localhost:4200")
public class FeedbackController {

    private final FeedbackService feedbackService;

    public FeedbackController(FeedbackService feedbackService) { this.feedbackService = feedbackService; }

    @PostMapping("/user/{userId}")
    public Feedback createFeedback(@PathVariable Long userId, @Valid @RequestBody Feedback feedback) {
        return feedbackService.createFeedback(feedback, userId);
    }

    @GetMapping("/admin/all")
    public List<Feedback> getAllFeedback() {
        return feedbackService.getAllFeedback();
    }
}
