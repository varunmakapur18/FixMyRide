export class Vehicle {
  id!: string;
  make!: string;
  model!: string;
  registrationNumber!: string;
  year!: number;
  userId!: string;
}

